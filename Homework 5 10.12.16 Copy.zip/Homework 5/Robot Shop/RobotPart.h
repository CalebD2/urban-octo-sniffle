#ifndef __ROBOTPART_H
#define __ROBOTPART_H 2016
#include <string>
#include <vector>
using namespace std;

void wrngSel();
int charToIntInpCk(int i,int j,char a);

class RobotPart{
public:
	RobotPart(string n, string num,string t) :
		name(n), partNum(num),type(t) {}

	void print();
	bool canBuild(vector<RobotPart> temp);

	string getName(){
        return name;
	}

	string getType(){
        return type;
	}

	string getPartNum(){
        return partNum;
	}

protected:
	string name;
	string type;
	string partNum;
};

#endif // !__ROBOTPART_H
