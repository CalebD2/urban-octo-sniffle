#include "BuildRobot.h"
#include <iostream>

string selPart(string part,vector<RobotPart> temp){
    int i, j = 1,selection;
    int track[10];

    while(true){
        cout << "\nWhich " << part << " would you like?\n";
        for(i = 0;i < temp.size();i++){
            if(part == temp[i].getType()){
                cout << "\t" << j << ". Type: " << temp[i].getType() << " Name: " << temp[i].getName()
                << " Part Number: " << temp[i].getPartNum() << endl;

                track[j-1] = i;
                j++;
            }
        }

        cout << "Selection: ";
        cin >> selection;
        if(selection > 0 && selection < j) break;
        else wrngSel();
    }

    return temp[track[selection-1]].getPartNum();
}

void buildRobot::print() {
	cout << "\tHead: " << head << " Arm: " << arm << " Torso: " << torso
	<< " Battery: " << battery << " Locomotor: " << locomotor << endl;
}
