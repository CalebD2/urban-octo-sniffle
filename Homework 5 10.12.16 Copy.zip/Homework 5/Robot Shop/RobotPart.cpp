//#include "stdafx.h"
//#include "../../../std_lib_facilities.h"
#include <iostream>
#include "RobotPart.h"
#include <vector>

using namespace std;

void RobotPart::print() {
	cout << "\tType: " << type << " Name: " << name << " Part Number: " << partNum << endl;
}

bool RobotPart::canBuild(vector<RobotPart> temp){
    int i, build = 0;
    bool hd = 1,arm = 1,trs = 1,btry = 1, loco = 1;
    for(i = 0; i < temp.size(); i++) {
        if(temp[i].type == "Head"){
            build += hd;
            hd = 0;
        }
        if(temp[i].type == "Arm"){
            build += arm;
            arm = 0;
        }
        if(temp[i].type == "Torso"){
            build += trs;
            trs = 0;
        }
        if(temp[i].type == "Battery"){
            build += btry;
            btry = 0;
        }
        if(temp[i].type == "Locomotor"){
            build += loco;
            loco = 0;
        }
    }
    if(build == 5)return true;
    else return false;
}
