#include <iostream>

using namespace std;

/* The wrngSel (wrong selection) function simply prints out that the user chose an invalid selection */

void wrngSel(){
    cout << "\nWhoops, this doesn't appear to be a selection!\n";
}

/*
The charToIntInpCk (char to int input check) function checks to see if
the number that is stored as a char type is in between the numbers held
by i and j. If this test fails, it will immediately return zero, else it
will then convert the char into an int and then return it

WARNING: THIS FUNCTION ONLY TAKES SINGLE CHAR INPUTS, AND CONSEQUENTLY
WILL NOT WORK ON DOUBLE DIGIT NUMBERS! THIS FUNCTION IS SIMPLY USEFUL
FOR MENU INPUT CHECKS!
*/

int charToIntInpCk(int i, int j, char a){
    i+=48;
    j+=48; /// Converts the numbers given to their "ascii" equivalent, to compare with a

    if(a < i || a > j){
        wrngSel();
        return 0;
    }

    else return a-48;
}
