#include <iostream>
//#include "stdafx.h"
//#include "..\..\..\std_lib_facilities.h"
#include <string>
#include "RobotPart.h"
#include <vector>
#include "BuildRobot.h"

using namespace std;

int main()
{
	char selection;
	int i;
	string name, partNum;
	string type[] = { "Head", "Arm", "Torso", "Battery", "Locomotor" };
	string head, arm, torso, batt, loco;
	vector<RobotPart> partList;
	vector<buildRobot> builtList;
	RobotPart build(" "," "," ");
	while (true) {
		cout << "\n Creating a part \nWhat Type of part is it?\n\t1)Head\n\t2)Arm\n\t3)Torso\n\t4)Battery\n\t5)Locomotor\nchoice: ";
		cin >> selection;
		cin.ignore();
		i = charToIntInpCk(1,5,selection);
		if(i){
            cout << "What is the name of the part: ";
            getline(cin, name);
            cout << "What is the part number: ";
            getline(cin, partNum);

            RobotPart temp(name, partNum,type[i-1]);
            partList.push_back(temp);

            cout << "listing all parts: \n";
            for(i = 0; i < partList.size(); i++) {
                partList[i].print();
            }
		}
        if(build.canBuild(partList)){
            cout << "\nYou have enough parts to build!\nWould you like to build?\n1. Yes\n2. No\nSelection: ";
            cin >> selection;
            i = charToIntInpCk(1,2,selection);
            if(i == 1){
                head = selPart("Head",partList);
                arm = selPart("Arm",partList);
                torso = selPart("Torso",partList);
                batt = selPart("Battery",partList);
                loco = selPart("Locomotor",partList);

                buildRobot partSet(head,arm,torso,batt,loco);
                builtList.push_back(partSet);
            }
            cout << "\nListing all built robots: \n";
            for(i = 0; i < builtList.size(); i++) {
                builtList[i].print();
            }
        }
	}
}


