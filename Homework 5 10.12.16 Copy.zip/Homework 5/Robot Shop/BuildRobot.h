#include <vector>
#include "RobotPart.h"

#ifndef BUILDROBOT_H_INCLUDED
#define BUILDROBOT_H_INCLUDED

using namespace std;

bool canBuild(vector<RobotPart> temp);
string selPart(string part,vector<RobotPart> temp);

class buildRobot{
public:
    buildRobot(string h, string a, string t, string b, string l) :
    head(h), arm(a), torso(t), battery(b), locomotor(l){}

    void print();

private:

protected:
    string head;
    string arm;
    string torso;
    string battery;
    string locomotor;
};


#endif // BUILDROBOT_H_INCLUDED
